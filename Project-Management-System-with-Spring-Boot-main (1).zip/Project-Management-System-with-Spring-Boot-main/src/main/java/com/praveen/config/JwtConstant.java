package com.praveen.config;

public class JwtConstant {
    public static final String SECRET_KEY="jkdsvbhjb lhhir hub uhb jjasnlsahithihsan ih2loqh hads";
    public static final String JWT_HEADER="Authorization";
}
