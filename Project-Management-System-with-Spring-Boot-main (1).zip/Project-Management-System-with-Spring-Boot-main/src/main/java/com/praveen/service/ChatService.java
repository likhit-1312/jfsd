package com.praveen.service;

import com.praveen.model.Chat;

public interface ChatService {
    
    Chat createChat(Chat chat);
}
