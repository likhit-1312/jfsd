package com.praveen.model;

public enum PlanType {
    FREE,
    MONTHLY,
    ANNUALLY
}
